package com.example.example;

/**
 * Hello world!
 *
 */
public class App {
    public static void main( String[] args ){
        System.out.println( "Hello World!" );
		App a = new App();
		int numberOfYears = a.callCalculator();
    }
	
	public int callCalculator(){
		return 20;
}
}